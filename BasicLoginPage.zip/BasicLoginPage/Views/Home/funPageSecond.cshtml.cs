using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BasicLoginPage.Views.Home
{
    public class funPageSecondModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
