//using Microsoft.AspNetCore.Mvc;
//using Microsoft.AspNetCore.Mvc.RazorPages;

//namespace BasicLoginPage.Views.Home
//{
//    public class funPageModel : PageModel
//    {
//        public void OnGet()
//        {
//        }
//    }
//}
