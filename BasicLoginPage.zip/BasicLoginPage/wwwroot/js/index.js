﻿document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("loginForm");
    const showHintButton = document.getElementById("showHint");
    const passwordHint = document.getElementById("passwordHint");

    form.addEventListener("submit", function (e) {
        e.preventDefault(); // prevent default server post

        const username = document.getElementById("username").value;
        const password = document.getElementById("password").value;



        if (username == "ihaveplans" && password === "momo") {
            window.location.href = "/Home/Welcome";
        } else {
            alert("Incorrect password");
        }
    });


    // Toggle the password hint visibility
    showHintButton.addEventListener("click", function () {
        if (passwordHint.style.display === "none") {
            passwordHint.style.display = "inline";
        } else {
            passwordHint.style.display = "none";
        }
    });

});
