using System.Diagnostics;
using BasicLoginPage.Models;
using Microsoft.AspNetCore.Mvc;

namespace BasicLoginPage.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }


        public IActionResult Welcome()
        {
            return View(); // should be /Views/Home/Welcome.cshtml
        }
        public IActionResult funPage()
        {
            return View(); // should be /Views/Home/funPage.cshtml
        }
        public IActionResult funPageSecond()
        {
            return View(); // should be /Views/Home/funPageSecond.cshtml
        }
        public IActionResult last()
        {
            return View(); // should be /Views/Home/last.cshtml
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(string username, string password)
        {
            if (username == "ihaveplans" && password == "momo")
            {
                // Login successful - redirect to a success or home page
                return RedirectToAction("Index");
            }

            ViewBag.Message = "Invalid username or password.";
            return View();
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
